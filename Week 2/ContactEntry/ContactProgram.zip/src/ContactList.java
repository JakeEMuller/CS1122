import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class ContactList {
    ArrayList<ContactEntry> list;
    int entries;

    public ContactList() {
        list = new ArrayList<ContactEntry>();
        entries = 0; //number of entries in the list
    }

    public ArrayList<ContactEntry> getList() {
        return list;
    }

    public void setList(ArrayList<ContactEntry> list) {
        this.list = list;
    }

    public int getEntries() {
        return entries;
    }

    public void setEntries(int entries) {
        this.entries = entries;
    }

    void addEntry(String name, String email) {
        // add a new item at the end of the list.
        ContactEntry entry = new ContactEntry(name, email);
        list.add(entry);
        entries++;
    }

    String getEmail(String name) {
        // return email associated with name,
        // or return null if the name does not occur in the list.
        for (int index = 0; index < entries; index++) {
            ContactEntry entry = list.get(index);
            if (name.equals(entry.getName())) { // found it!
                return list.get(index).getEmail();

            }
        }
        return null; // name wasnt found
    }

    public static ContactList loadContacts(String filepath) {
        ArrayList<String> info = new ArrayList<String>();
        ContactList test = new ContactList();
        Scanner scan = new Scanner(System.in);
        File contacts = new File(filepath);
        try { // catches file not found exception
            scan = new Scanner(contacts);
            while (scan.hasNext()) { // reads the file and adds it to an ArrayList
                info.add(scan.next());
            }
            for (int i = 0; info.size() > i; i++) {
                String name = "";
                String email = "";
                int type = 0; // 0 for name, 1 for email
                for (int j = 0; info.get(i).length() > j; j++) {
                    char colon = info.get(i).charAt(j);
                    if (colon == ':') { // once the colon is found it switches to the email varable
                        type++;
                        j++;
                    }
                    if (type == 0) { // tests to see if the methods should be loading to name or email
                        name += Character.toString(info.get(i).charAt(j));
                    } else if (type == 1) {
                        email += Character.toString(info.get(i).charAt(j));
                    }

                }
                test.addEntry(name, email); // adds to entry
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (scan != null) {
                scan.close();
            }
        }
        return test;
    }

    public void storeContacts(String filepath) {
        try (PrintWriter pwt = new PrintWriter(filepath)){
            for (int i = 0; getEntries() > i; i++) {
                String name = getList().get(i).getName();
                String email = getList().get(i).getEmail();
                pwt.print(name);
                pwt.print(":");
                pwt.println(email);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

    public String toString() {
        ArrayList<String> result = new ArrayList<>();
        for (int i = 0; getEntries() > i; i++) {
            String info = "";
            info += getList().get(i).getName();
            info += ":" + getList().get(i).getEmail();
            result.add(info);
        }
        return result.toString();
    }

    public static void main(String[] args) {
        ContactList user = new ContactList();
        Scanner ui = new Scanner(System.in);
        String action = "";
        while (!action.equalsIgnoreCase("Close")) {
            System.out.println("Enter a command (Enter \"help\" for help, Enter Close to terminate)");
            action = ui.next();
            if (action.equalsIgnoreCase("help")) {
                System.out.println("\"help\", list all commands");
                System.out.println("\"add\", add a contact to the list");
                System.out.println("\"load\", load contacts from a list (Note this replaces contacts list)");
                System.out.println("\"store\", store contacts to a text document\n");
            }
            if (action.equalsIgnoreCase("load")) {
                System.out.println("what file would you like to load from");
                Scanner temp = new Scanner(System.in);
                String file = temp.next();
                user = ContactList.loadContacts(file);
                System.out.println("you have loaded from " + file);
            } else if (action.equalsIgnoreCase("add")) {
                Scanner test = new Scanner(System.in);
                System.out.println("please enter an name and email separtated by a colon (Example, \"Joe Schome:jSchome@gmail.com\")");
                String nameEmail = test.nextLine();
                String[] info = nameEmail.split(":");
                String name = info[0];
                String email = info[1];
                user.addEntry(name, email);

            } else if (action.equalsIgnoreCase("store")) {
                System.out.println("Enter the name of the file you would like to store your contacts in (Example \"test.txt\")");
                String fileName = ui.next();
                user.storeContacts(fileName);
            } else {
                System.out.println("That is not a command, please enter a command. (Enter \"help\" for commands)");
            }

        }
    }
}